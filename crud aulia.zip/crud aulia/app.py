from flask import Flask, request, jsonify, render_template, redirect, url_for
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS todos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

#HTML Routes

@app.route('/')
def index():
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("SELECT * FROM todos")
    todos = c.fetchall()
    conn.close()
    return render_template('index.html', todos=todos)

@app.route('/add', methods=['POST'])
def add():
    task = request.form['task']
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("INSERT INTO todos (task) VALUES (?)", (task,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/delete/<int:id>')
def delete(id):
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("DELETE FROM todos WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/edit/<int:id>')
def edit(id):
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("SELECT * FROM todos WHERE id=?", (id,))
    todo = c.fetchone()
    conn.close()
    return render_template('edit.html', todo=todo)

@app.route('/update/<int:id>', methods=['POST'])
def update(id):
    new_task = request.form['task']
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("UPDATE todos SET task=? WHERE id=?", (new_task, id))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

#API Route

@app.route('/api/todos', methods=['GET'])
def get_todos():
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("SELECT * FROM todos")
    todos = [{'id': row[0], 'task': row[1]} for row in c.fetchall()]
    conn.close()
    return jsonify(todos)

@app.route('/api/todos', methods=['POST'])
def add_todo():
    data = request.get_json()
    task = data.get('task')
    if not task:
        return jsonify({'error': 'Task is required'}), 400
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("INSERT INTO todos (task) VALUES (?)", (task,))
    conn.commit()
    new_id = c.lastrowid
    conn.close()
    return jsonify({'id': new_id, 'task': task}), 201

@app.route('/api/todos/<int:id>', methods=['PUT'])
def update_todo(id):
    data = request.get_json()
    new_task = data.get('task')
    if not new_task:
        return jsonify({'error': 'Task is required'}), 400
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("UPDATE todos SET task=? WHERE id=?", (new_task, id))
    conn.commit()
    conn.close()
    return jsonify({'id': id, 'task': new_task})

@app.route('/api/todos/<int:id>', methods=['DELETE'])
def delete_todo(id):
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("DELETE FROM todos WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return jsonify({'message': f'Task {id} deleted'})

@app.route('/api/todos/<int:id>', methods=['GET'])
def get_todo_by_id(id):
    conn = sqlite3.connect('todos.db')
    c = conn.cursor()
    c.execute("SELECT * FROM todos WHERE id=?", (id,))
    row = c.fetchone()
    conn.close()

    if row:
        return jsonify({'id': row[0], 'task': row[1]})
    else:
        return jsonify({'error': 'Task not found'}), 404


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
